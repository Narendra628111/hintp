def show_dashboard(user_id):
    print(f"Showing dashboard for user: {user_id}")