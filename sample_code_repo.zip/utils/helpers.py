def format_date(date_str):
    return date_str.replace("-", "/")